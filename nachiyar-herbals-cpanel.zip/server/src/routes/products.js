const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

function slugify(text) {
  return (text || '')
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// Map DB row to camelCase format expected by frontends
function mapProduct(row) {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    subtitle: row.subtitle,
    category: row.category,
    categoryId: row.category_id,
    price: Number(row.price),
    mrp: Number(row.mrp),
    stock: Number(row.stock),
    initialStock: Number(row.initial_stock),
    onlineSold: Number(row.online_sold),
    offlineSold: Number(row.offline_sold),
    sku: row.sku,
    images: typeof row.images === 'string' ? JSON.parse(row.images) : (row.images || []),
    themeColor: row.theme_color,
    tagline: row.tagline,
    metricBadge: row.metric_badge,
    badge: row.badge,
    shortDescription: row.short_description,
    description: row.description,
    benefits: typeof row.benefits === 'string' ? JSON.parse(row.benefits) : (row.benefits || []),
    ingredients: row.ingredients,
    howToUse: row.how_to_use,
    variants: typeof row.variants === 'string' ? JSON.parse(row.variants) : (row.variants || []),
    seo: typeof row.seo === 'string' ? JSON.parse(row.seo) : (row.seo || {}),
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

// Self-healing: ensure product categories are accurately categorized in database
async function healProductCategories() {
  try {
    // 1. Shampoos -> Scalp & Cleansing
    await query(`
      UPDATE products 
      SET category = 'Scalp & Cleansing', category_id = 'cat_scalp' 
      WHERE (LOWER(name) LIKE '%shampoo%' OR LOWER(slug) LIKE '%shampoo%')
        AND LOWER(name) NOT LIKE '%combo%' 
        AND LOWER(name) NOT LIKE '%duo%' 
        AND LOWER(name) NOT LIKE '%set%' 
        AND (category IS NULL OR category = 'Hair Care');
    `);

    // 2. Combos / Sets -> Ritual Sets
    await query(`
      UPDATE products 
      SET category = 'Ritual Sets', category_id = 'cat_sets' 
      WHERE (LOWER(name) LIKE '%combo%' OR LOWER(name) LIKE '%duo%' OR LOWER(name) LIKE '%set%' OR LOWER(slug) LIKE '%combo%' OR LOWER(slug) LIKE '%duo%')
        AND (category IS NULL OR category = 'Hair Care' OR category = 'Ritual Combos');
    `);
  } catch (err) {
    // Non-fatal if DB not yet initialized
  }
}
healProductCategories();

// 1. GET /api/products
router.get('/', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    const { category, q } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (category) {
      params.push(category.toLowerCase());
      sql += ` AND (LOWER(category) = $${params.length} OR category_id = $${params.length})`;
    }

    if (q) {
      params.push(`%${q.toLowerCase()}%`);
      sql += ` AND (LOWER(name) LIKE $${params.length} OR LOWER(short_description) LIKE $${params.length})`;
    }

    sql += ' ORDER BY created_at ASC';

    const result = await query(sql, params);
    res.json({ success: true, data: result.rows.map(mapProduct) });
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 2. GET /api/products/:idOrSlug
router.get('/:idOrSlug', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    const { idOrSlug } = req.params;
    const cleanParam = decodeURIComponent(idOrSlug || '').trim().toLowerCase();
    const slugVariant = slugify(cleanParam);

    const result = await query(
      'SELECT * FROM products WHERE LOWER(id) = $1 OR LOWER(slug) = $1 OR LOWER(slug) = $2 LIMIT 1',
      [cleanParam, slugVariant]
    );

    if (result.rows.length === 0) {
      const fallbackResult = await query(
        'SELECT * FROM products WHERE slug LIKE $1 LIMIT 1',
        ['%' + slugVariant + '%']
      );
      if (fallbackResult.rows.length > 0) {
        return res.json({ success: true, data: mapProduct(fallbackResult.rows[0]) });
      }
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    res.json({ success: true, data: mapProduct(result.rows[0]) });
  } catch (err) {
    console.error('Error fetching product:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 3. POST /api/products
router.post('/', async (req, res) => {
  try {
    const body = req.body;
    if (!body.name || !body.price) {
      return res.status(400).json({ success: false, message: 'Product name and price are required' });
    }

    const id = body.id || `prod_${Date.now()}`;
    const rawSlug = (body.slug || '').trim() || (body.name || '').trim();
    let slug = slugify(rawSlug) || `prod-${Date.now()}`;
    const existingSlug = await query('SELECT id FROM products WHERE slug = $1 LIMIT 1', [slug]);
    if (existingSlug.rows.length > 0) {
      slug = `${slug}-${Date.now().toString().slice(-4)}`;
    }
    const price = Number(body.price);
    const mrp = Number(body.mrp) || Math.round(price * 1.2);
    const stock = Number(body.stock) || 0;
    const initialStock = stock;
    const sku = body.sku || `NH-${Date.now().toString().slice(-6)}`;
    const images = body.images && body.images.length ? body.images : ['assets/herbal-hair-oil.jpg'];
    const themeColor = body.themeColor || '#6B4E9B';
    const tagline = body.tagline || '100% Pure Botanical Infusion';
    const metricBadge = body.metricBadge || '100% PURE';
    const badge = body.badge || 'New';
    let category = body.category || 'Hair Care';
    let categoryId = body.categoryId || 'cat_hair_care';
    const nameLower = (body.name || '').toLowerCase();
    if (category === 'Hair Care') {
      if (nameLower.includes('shampoo') && !nameLower.includes('combo') && !nameLower.includes('set')) {
        category = 'Scalp & Cleansing';
        categoryId = 'cat_scalp';
      } else if (nameLower.includes('combo') || nameLower.includes('duo') || nameLower.includes('set')) {
        category = 'Ritual Sets';
        categoryId = 'cat_sets';
      }
    }


    const insertSql = `
      INSERT INTO products (
        id, slug, name, subtitle, category, category_id,
        price, mrp, stock, initial_stock, online_sold, offline_sold,
        sku, images, theme_color, tagline, metric_badge, badge,
        short_description, description, benefits, ingredients, how_to_use,
        variants, seo, status
      ) VALUES (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, 0, 0,
        $11, $12, $13, $14, $15, $16,
        $17, $18, $19, $20, $21,
        $22, $23, $24
      ) RETURNING *;
    `;

    const values = [
      id,
      slug,
      body.name,
      body.subtitle || '',
      category,
      categoryId,
      price,
      mrp,
      stock,
      initialStock,
      sku,
      JSON.stringify(images),
      themeColor,
      tagline,
      metricBadge,
      badge,
      body.shortDescription || '',
      body.description || '',
      JSON.stringify(body.benefits || []),
      body.ingredients || '',
      body.howToUse || '',
      JSON.stringify(body.variants || []),
      JSON.stringify(body.seo || { metaTitle: `${body.name} | Nachiyar Herbals`, metaDescription: body.shortDescription || '', keywords: 'herbal', slug }),
      body.status || 'active'
    ];

    const result = await query(insertSql, values);
    res.status(201).json({ success: true, data: mapProduct(result.rows[0]) });
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 4. PUT /api/products/:id
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body;

    const existingResult = await query('SELECT * FROM products WHERE id = $1', [id]);
    if (existingResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    const current = existingResult.rows[0];

    const prevStock = Number(current.stock);
    const newStock = body.stock !== undefined ? Number(body.stock) : prevStock;

    // Track inventory log if stock changed manually
    if (newStock !== prevStock) {
      const logSql = `
        INSERT INTO inventory_logs (
          id, product_id, product_name, channel, reference,
          change, prev_stock, new_stock, timestamp, reason
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), $9)
      `;
      await query(logSql, [
        `log_${Date.now()}`,
        id,
        current.name,
        'admin_adjustment',
        'Manual Edit',
        newStock - prevStock,
        prevStock,
        newStock,
        'Manual stock adjustment in Product Manager'
      ]);
    }

    const updateSql = `
      UPDATE products SET
        name = COALESCE($1, name),
        subtitle = COALESCE($2, subtitle),
        category = COALESCE($3, category),
        category_id = COALESCE($4, category_id),
        price = COALESCE($5, price),
        mrp = COALESCE($6, mrp),
        stock = $7,
        sku = COALESCE($8, sku),
        images = COALESCE($9, images),
        theme_color = COALESCE($10, theme_color),
        tagline = COALESCE($11, tagline),
        badge = COALESCE($12, badge),
        short_description = COALESCE($13, short_description),
        description = COALESCE($14, description),
        benefits = COALESCE($15, benefits),
        ingredients = COALESCE($16, ingredients),
        how_to_use = COALESCE($17, how_to_use),
        variants = COALESCE($18, variants),
        status = COALESCE($19, status),
        slug = COALESCE($20, slug),
        updated_at = NOW()
      WHERE id = $21
      RETURNING *;
    `;

    let finalVariants = null;
    if (body.variants) {
      finalVariants = typeof body.variants === 'string' ? body.variants : JSON.stringify(body.variants);
    } else if (current.variants && body.price !== undefined) {
      try {
        let vars = typeof current.variants === 'string' ? JSON.parse(current.variants) : current.variants;
        if (Array.isArray(vars) && vars.length > 0) {
          let stdIdx = vars.findIndex(v => 
            (v.id && (v.id.includes('200') || v.id.includes('250') || v.id.includes('standard') || v.id.includes('std'))) ||
            (v.name && (v.name.includes('200ml') || v.name.includes('250ml') || v.name.includes('Standard') || v.name.includes('Full Ritual')))
          );
          if (stdIdx === -1) stdIdx = 0;
          vars[stdIdx].price = Number(body.price);
          if (body.mrp !== undefined) {
            vars[stdIdx].mrp = Number(body.mrp);
          }
          finalVariants = JSON.stringify(vars);
        }
      } catch (e) {
        console.warn('Could not auto-sync variant price:', e);
      }
    }

    const values = [
      body.name || null,
      body.subtitle || null,
      body.category || null,
      body.categoryId || null,
      body.price !== undefined ? Number(body.price) : null,
      body.mrp !== undefined ? Number(body.mrp) : null,
      newStock,
      body.sku || null,
      body.images ? JSON.stringify(body.images) : null,
      body.themeColor || null,
      body.tagline || null,
      body.badge || null,
      body.shortDescription || null,
      body.description || null,
      body.benefits ? JSON.stringify(body.benefits) : null,
      body.ingredients || null,
      body.howToUse || null,
      finalVariants,
      body.status || null,
      (body.slug || body.name) ? slugify((body.slug || body.name).trim()) : null,
      id
    ];

    const result = await query(updateSql, values);
    res.json({ success: true, data: mapProduct(result.rows[0]) });
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 5. DELETE /api/products/:id
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('DELETE FROM products WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, message: 'Product removed', data: mapProduct(result.rows[0]) });
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
